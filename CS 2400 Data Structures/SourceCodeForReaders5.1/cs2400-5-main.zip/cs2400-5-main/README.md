# Project-5

https://github.com/desantamaria/Project-5

Interfaces were used for the ADTs and Graphs

We used an adjacency list version of the graph implementation and a linked dictionary to store the vertices and its edges.

To run the code open "TestFile.java"; compile and run.